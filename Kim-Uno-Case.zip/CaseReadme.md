# Kim Uno Case

## Instructions for making a case for the Kim Uno.

1. Laser-cut the top, keys and bottom from 3mm translucent acrylic.
2. 3D print the frame
3. Screw the bottom plate to the frame
4. Glue the keys to the square parts and place in the right location on the top.
5. Screw the top plate and keys to the assembled PCB, using a spacer to get the height just right - the keys should depress the tactile switches.
6. Attach the battery, use double-sided tape to secure to the bottom plate.
7. Set the top assembly into the frame. The same screws that hold the top plate and PCB together should screw into the frame supports.
